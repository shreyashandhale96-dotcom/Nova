import React, { useState } from "react";
import { Nova } from "./Nova";

const nova = new Nova();

export default function App() {
  const [order, setOrder] = useState("");
  const [skills, setSkills] = useState(nova.getSkills());

  const handleAddOrder = () => {
    if (order.trim() === "") return;
    nova.addOrder(order);
    setSkills([...nova.getSkills()]);
    setOrder("");
  };

  const handleApprove = (index: number) => {
    nova.approveSkill(index, "AI/YouTube source");
    setSkills([...nova.getSkills()]);
  };

  const handleExecute = (index: number) => {
    nova.executeSkill(index);
    setSkills([...nova.getSkills()]);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Nova Orchestrator (Day 1)</h1>
      <input
        value={order}
        onChange={(e) => setOrder(e.target.value)}
        placeholder="Give Nova an order..."
        style={{ marginRight: 10 }}
      />
      <button onClick={handleAddOrder}>Add Order</button>

      <ul>
        {skills.map((skill, i) => (
          <li key={i}>
            <b>{skill.name}</b> — {skill.status}
            {skill.status === "pending" && (
              <button onClick={() => handleApprove(i)}>Approve</button>
            )}
            {skill.status === "approved" && (
              <button onClick={() => handleExecute(i)}>Execute</button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
